# UV Echo Plugin

用于覆盖 `manager.Install` 的完整依赖安装链路（含 UV 路径）。该插件会在 `tool.invoke` 时调用 `requests` 拉取一个 URL，因此需要网络下载依赖。

## 目录
```
test_plugin/uv_echo_0.0.1/
  ├─ main_runner.py     # 入口，兼容 plugin-runner 协议
  ├─ requirements.txt   # 包含 requests，触发 pip/uv 安装
  └─ manifest.yaml      # 方便查看元信息（安装时仍由 API/测试传入 manifest）
```

## 打包
```
cd test_plugin/uv_echo_0.0.1
zip -r ../uv_echo_0.0.1.zip .
```

## 安装与运行（示例）
1. 准备环境变量（示例使用本地 Postgres/Redis 配置）：
   ```
   export EXECUTOR_PLUGIN_HOME=/Users/vic/GolandProjects/zgi-plugin-runner/plugins
   export EXECUTOR_WORKSPACE_PATH=/Users/vic/GolandProjects/zgi-plugin-runner/workspace
   export EXECUTOR_PACKAGE_CACHE_PATH=/Users/vic/GolandProjects/zgi-plugin-runner/cache
   export EXECUTOR_HTTP_PORT=15000
   export EXECUTOR_API_KEY=test-api-key
   export EXECUTOR_ADMIN_API_KEYS=admin-key-123
   ```

2. 确保 UV 可用（会走 `installDependencies` 的 UV 分支）：
   ```
   pip install --user uv
   export EXECUTOR_UV_PATH=$(python3 -c "import uv, pathlib; from uv._find_uv import find_uv_bin; print(find_uv_bin())")
   ```

3. 在 API 端注册并安装：
   - 注册 manifest（可参考 main_runner 中的元信息，或直接在调用中构造）：
     ```
     curl -X POST http://127.0.0.1:15000/api/v1/plugins \
       -H "X-API-Key: admin-key-123" \
       -H "Content-Type: application/json" \
       -d '{
         "id": "uv-echo:0.0.1",
         "name": "uv-echo",
         "version": "0.0.1",
         "author": "vic",
         "runner": {"language": "python", "entrypoint": "main_runner"},
         "requirements": {"packages": []}
       }'
     ```
   - 上传压缩包完成安装：
     ```
     curl -X POST http://127.0.0.1:15000/api/v1/plugins/uv-echo:0.0.1/install \
       -H "X-API-Key: admin-key-123" \
       -F "file=@test_plugin/uv_echo_0.0.1.zip"
     ```

4. 验证：
   ```
   curl -H "X-API-Key: test-api-key" http://127.0.0.1:15000/api/v1/plugins/installed
   ```
   应可看到 `uv-echo`，并且工作目录下存在 `.venv`（或 UV 环境）以及 `requests` 安装。

## 行为说明
- `action=list_tools` 返回 `echo_http` 工具定义。
- `action=tool.invoke` 传 `name=echo_http`（或 `echo`），可选参数：
  - `url`（默认 `https://httpbin.org/get`）
  - `message`（默认 `hello-from-uv-echo`）
- 请求会通过 `requests` 执行 GET，返回状态码、消息和响应体长度。

## 覆盖点
- 包含 `requirements.txt`，确保 `installDependencies` 会创建 venv 并执行 pip/uv。
- 设置 `EXECUTOR_UV_PATH` 时，走 UV venv 创建与安装分支；未设置时走标准 `python -m venv + pip` 分支。
- 网络依赖（requests）确保实际下载发生，便于验证隔离与安装日志。
